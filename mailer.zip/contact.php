<?php
use PHPMailer\PHPMailer\PHPMailer;
use PHPMailer\PHPMailer\SMTP;
use PHPMailer\PHPMailer\Exception;

require_once "vendor/autoload.php";

$name = $_POST['name'];
$visitor_email = $_POST['email'];
$message = $_POST['massage'];

$email_subject = "Website Contact Enquiry Form";
$email_body = "User Name: $name.\n".
              "User Email:  $visitor_email.\n".
              "User Message: $message.\n";


$mail = new PHPMailer(true);

//Enable SMTP debugging.
$mail->SMTPDebug = 3;                               
//Set PHPMailer to use SMTP.
$mail->isSMTP();            
//Set SMTP host name                          
$mail->Host = "smtppro.zoho.in";

//Set this to true if SMTP host requires authentication to send email
$mail->SMTPAuth = true;                          
//Provide username and password     
$mail->Username = "notifications@butterflycastles.com";                 
$mail->Password = "Butterfly@8901";  // Give zoho corresponding password                         
//If SMTP requires TLS encryption then set it
$mail->SMTPSecure = "tls";                           
//Set TCP port to connect to
$mail->Port = 587;                                   

$mail->From = "notifications@butterflycastles.com";
$mail->FromName = "Butterflycastles";

$mail->addAddress("info@butterflycastles.com", "Butterflycastles");

$mail->isHTML(true);

$mail->Subject = $email_subject;
$mail->Body = $email_body;
$mail->AltBody = "This is the plain text version of the email content";

try {
    $mail->send();
    echo "Message has been sent successfully";
} catch (Exception $e) {
    echo "Mailer Error: " . $mail->ErrorInfo;
}

?>










