<?php
use PHPMailer\PHPMailer\PHPMailer;
use PHPMailer\PHPMailer\SMTP;
use PHPMailer\PHPMailer\Exception;

require_once "vendor/autoload.php";

if(isset($_POST['submit']))
{
                $name = $_POST['name']; // Get Name value from HTML Form
                $email_id = $_POST['email']; // Get Email Value
                $mobile_no = $_POST['mobile']; // Get Mobile No
                $msg = ''; //$_POST['message']; // Get Message Value
                
                $email_subject = "Admission Enquiry";
                // HTML Message Starts here
                $email_body ="
                <html>
                    <body>
                        <table style='width:600px;'>
                            <tbody>
                                <tr>
                                    <td style='width:150px'><strong>Name: </strong></td>
                                    <td style='width:400px'>$name</td>
                                </tr>
                                <tr>
                                    <td style='width:150px'><strong>Email ID: </strong></td>
                                    <td style='width:400px'>$email_id</td>
                                </tr>
                                <tr>
                                    <td style='width:150px'><strong>Mobile No: </strong></td>
                                    <td style='width:400px'>$mobile_no</td>
                                </tr>
                                <tr>
                                    <td style='width:150px'><strong>Message: </strong></td>
                                    <td style='width:400px'>$msg</td>
                                </tr>
                            </tbody>
                        </table>
                    </body>
                </html>
                ";
                // HTML Message Ends here

    $mail = new PHPMailer(true);

    //Enable SMTP debugging.
    $mail->SMTPDebug = 3;                               
    //Set PHPMailer to use SMTP.
    $mail->isSMTP();            
    //Set SMTP host name                          
    $mail->Host = "smtppro.zoho.in";
    //Set this to true if SMTP host requires authentication to send email
    $mail->SMTPAuth = true;                          
    //Provide username and password     
    $mail->Username = "notifications@butterflycastles.com";                 
    $mail->Password = "Butterfly@8901";  // Give zoho corresponding password                         
    //If SMTP requires TLS encryption then set it
    $mail->SMTPSecure = "tls";                           
    //Set TCP port to connect to
    $mail->Port = 587;                                   

    $mail->From = "notifications@butterflycastles.com";
    $mail->FromName = "Butterflycastles";

    $mail->addAddress("info@butterflycastles.com", "Butterflycastles-Admissions");

    $mail->isHTML(true);

    $mail->Subject = $email_subject;
    $mail->Body = $email_body;
    $mail->AltBody = "This is the plain text version of the email content";

    try {
        $mail->send();
        echo "Message has been sent successfully";
    } catch (Exception $e) {
        echo "Mailer Error: " . $mail->ErrorInfo;
    }

}

?>

<?php
    // if(isset($_POST['submit']))
    // {
    //     $name = $_POST['name']; // Get Name value from HTML Form
    //     $email_id = $_POST['email']; // Get Email Value
    //     $mobile_no = $_POST['mobile']; // Get Mobile No
    //     $msg = $_POST['message']; // Get Message Value
         
    //     $to = "jithinclt91@gmail.com"; // You can change here your Email
    //     $subject = "'$name' has been sent a mail"; // This is your subject
         
    //     // HTML Message Starts here
    //     $message ="
    //     <html>
    //         <body>
    //             <table style='width:600px;'>
    //                 <tbody>
    //                     <tr>
    //                         <td style='width:150px'><strong>Name: </strong></td>
    //                         <td style='width:400px'>$name</td>
    //                     </tr>
    //                     <tr>
    //                         <td style='width:150px'><strong>Email ID: </strong></td>
    //                         <td style='width:400px'>$email_id</td>
    //                     </tr>
    //                     <tr>
    //                         <td style='width:150px'><strong>Mobile No: </strong></td>
    //                         <td style='width:400px'>$mobile_no</td>
    //                     </tr>
    //                     <tr>
    //                         <td style='width:150px'><strong>Message: </strong></td>
    //                         <td style='width:400px'>$msg</td>
    //                     </tr>
    //                 </tbody>
    //             </table>
    //         </body>
    //     </html>
    //     ";
    //     // HTML Message Ends here
         
    //     // Always set content-type when sending HTML email
    //     $headers = "MIME-Version: 1.0" . "\r\n";
    //     $headers .= "Content-type:text/html;charset=UTF-8" . "\r\n";
 
    //     // More headers
    //     $headers .= 'From: Admin <jithinclt91@gmail.com>' . "\r\n"; // Give an email id on which you want get a reply. User will get a mail from this email id
    //     $headers .= 'Cc: jithinclt91@gmail.com' . "\r\n"; // If you want add cc
    //     $headers .= 'Bcc: jithinclt91@gmail.com' . "\r\n"; // If you want add Bcc
         
    //     if(mail($to,$subject,$message,$headers)){
    //         // Message if mail has been sent
    //         echo "<script>
    //                 alert('Mail has been sent Successfully.');
    //             </script>";
    //     }
 
    //     else{
    //         // Message if mail has been not sent
    //         echo "<script>
    //                 alert('EMAIL FAILED');
    //             </script>";
    //     }
    // }
?>